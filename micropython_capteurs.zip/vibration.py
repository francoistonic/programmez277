import micropython
from machine import Pin, disable_irq, enable_irq
import time

micropython.alloc_emergency_exception_buf(100)

p = Pin( 22, Pin.IN, Pin.PULL_UP )
led = Pin( 25, Pin.OUT, value=False ) # OnBoard LED

last_detect = None

def detect_cb( pin ):
    global last_detect
    last_detect = time.ticks_ms()
    print( 'CB call' )
    
p.irq( handler=detect_cb, trigger=Pin.IRQ_FALLING )

while True:
    led.value( last_detect!=None )
    if (last_detect!=None) and ( time.ticks_diff(time.ticks_ms(), last_detect )> 2_000 ):
        last_detect = None
        print( 'disable' )
    time.sleep_ms( 10 )
    
