from machine import I2C, Pin
from sgp30 import SGP30
import time

i2c = I2C(1, sda=Pin(6), scl=Pin(7))
sgp = SGP30(i2c=i2c)

while True:
    eco2,tvoc = sgp.iaq_measure()
    print( "eCO2 = %s ppm, TVOC = %s ppb" % (eco2,tvoc) )
    time.sleep( 1 )
