from machine import Pin
import dht

dht = dht.DHT22( Pin(21) )
dht.measure()
print( 'Temp', dht.temperature() )
print( '%RH', dht.humidity() )
