from machine import I2C, Pin
from i2cenc import I2CEncoder
import time

i2c = I2C(1, sda=Pin(6), scl=Pin(7))
enc = I2CEncoder(i2c, address=0x40)

enc.color = (255,0,0) # Rouge
time.sleep( 0.5 )
enc.color = (0,255,0) # Vert
time.sleep( 0.5 )
enc.color = (0,0,255) # Bleu
time.sleep( 1 )
enc.color = (0,0,0) # Eteint

last_v = 0
while True:
	if enc.button: 
		print( "Button PRESSE")
	# -32768 <= v <= 32767
	v = enc.position
	if v != last_v: 
		print( v )
		last_v = v
	time.sleep_ms( 50 )