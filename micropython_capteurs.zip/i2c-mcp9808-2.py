from machine import Pin, I2C
from mcp9808 import MCP9808
import time

i2c = I2C(1,sda=Pin(6),scl=Pin(7))
mcp1 = MCP9808( i2c, address=0x1B )
mcp2 = MCP9808( i2c, address=0x1C )
while True:
    print( "Temperatures %s C - %s C" % (mcp1.temperature,mcp2.temperature) )
    time.sleep( 1 )