from machine import Pin
from onewire import OneWire
from ds18x20 import DS18X20
import time

def rom_to_hex( rom_id ):
   hex_parts = [ hex(val).replace('0x','') for val in rom_id ]
   hex_str = ':'.join( [ s if len(s)>1 else '0%s'%s for s in hex_parts ] )
   return hex_str.upper()

bus = OneWire( Pin(2) )
sensors = DS18X20( bus )
# Scan Bus
roms = sensors.scan()
for rom_id in roms:
    print( "ROM ID", rom_id, "ROM hex", rom_to_hex(rom_id) )

while True:
    sensors.convert_temp()
    time.sleep_ms( 750 )
    for rom_id in roms:
        print( rom_to_hex(rom_id), '=', sensors.read_temp(rom_id) , 'C' )
