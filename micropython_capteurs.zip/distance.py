from machine import Pin, time_pulse_us
from time import sleep_us, sleep_ms

class Ultrasonic:
	def __init__(self, trigger_pin_nr, echo_pin_nr):
		self.trigger = Pin(trigger_pin_nr)
		self.trigger.init(Pin.OUT)
		self.trigger.low()
		self.echo = Pin(echo_pin_nr)
		self.echo.init(Pin.IN)

	def distance_in_cm(self):
		self.trigger.high()
		sleep_us(10)
		self.trigger.low()
		usec = time_pulse_us( self.echo, 1)
		if usec < 0: # no echo response
			return 99999
		return (usec / 2) / 29

u = Ultrasonic( 28, 22 ) # Trigger, Echo
while True:
    dist = u.distance_in_cm()
    if dist < 400:
        print( "%i cm" % dist )
    sleep_ms( 100 )