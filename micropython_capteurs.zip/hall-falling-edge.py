from machine import Pin
import time

class PinEdge( Pin ):
    def __init__( self, id, mode=-1, pull=-1 ):
        super().__init__( id, mode, pull )
        self.last_state = self.value()
    
    @property
    def is_falling( self ):
        v = self.value()
        if v == self.last_state: # Not a new state ?
            return False
        time.sleep_ms( 10 )
        if self.value()!=v: # Are we still in same new state
            return False
        _falling = (self.last_state==True)and(v==False)
        self.last_state = v
        return _falling
    
p = PinEdge( 22, Pin.IN, Pin.PULL_UP )

count = 0
while True:
    if p.is_falling:
        count += 1
        print( 'Detection %i' % count )
    time.sleep_ms( 100 )