from machine import Pin
import time

class PinEdgeCollection():
    def __init__( self, pin_list ):
        assert all( [ isinstance(_pin, Pin) for _pin in pin_list ] ), "Requires Pin instances" 
        self._last_state = list( [_pin.value() for _pin in pin_list] )
        self._pins = pin_list
    
    @property
    def is_falling( self ):
        """ return None or list of pin_list index where a falling edge was detected """ 
        v = list([_pin.value() for _pin in self._pins ])
        v_and_last = list( zip( v, self._last_state) )
        # All the same than their previous state?
        if all( [_v == _last for _v,_last in v_and_last] ):
            return None
        time.sleep_ms( 10 )
        # Still at least one has a state change ?
        if any( [_v!=_pin.value() for _v, _pin in zip(v,self._pins)] ): 
            return None
        # At least one stays different
        # single falling pin detection = (last_state==True) and (current_value==False)
        _falling = list( [idx for idx, v_a_l in enumerate( v_and_last ) if (v_a_l[0]==False) and (v_a_l[1]==True) ] )
        # Storing the changed state as last_state
        for idx, _v in enumerate(v):
            self._last_state[idx] = _v
        return _falling if _falling else None

pins = []
for pin_nbr in (16,17,18,19,20):
    pins.append( Pin(pin_nbr, Pin.IN, Pin.PULL_UP) )
pin_labels = ['click','->','v','<-','^']

edge_col = PinEdgeCollection( pins )

count = 0
while True:
    indexes = edge_col.is_falling
    if indexes != None:
        count += 1
        lbs = [pin_labels[idx] for idx in indexes]
        print( 'Detection %i: %s , indexes: %s' % (count, ','.join(lbs), indexes  ))
    time.sleep_ms( 100 )