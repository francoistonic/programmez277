from machine import I2C, Pin
from bme280 import BME280
import time

i2c = I2C(1, sda=Pin(6), scl=Pin(7))
bme = BME280(i2c=i2c)

print(bme.values)