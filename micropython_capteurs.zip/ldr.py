from machine import Pin, ADC
import time

# Désactive PowerSafe (lower ripple)
Pin( 23, Pin.OUT, value=True )

a0 = ADC( Pin(26) )
while True:
    # Ponderation sur 10 mesures
    val = 0
    for i in range( 10 ):
        val += a0.read_u16()
    val = val/10
    
    volts = 3.3 * val / 65535
   
    print( 'adc=%5i volts=%.2f' % (val,volts) )
    time.sleep_ms( 300 )