from machine import Pin, I2C
from mcp9808 import MCP9808
import time

i2c = I2C(1,sda=Pin(6),scl=Pin(7))
mcp = MCP9808( i2c )
while True:
    print( "Temp %s C" % mcp.temperature )
    time.sleep( 1 )