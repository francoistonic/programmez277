# Test contact-magnetique
from machine import Pin
import time

p = Pin( 21, Pin.IN, Pin.PULL_UP )
while True:
    val = p.value()
    if val==0:
        print( "Porte Fermee" )
    else:
        print( "Porte Ouverte" )
    time.sleep( 0.5 )
