-- name: getBookWithAuthor1 :many
SELECT book.*, author.*
FROM book
JOIN author ON author.id = book.author_id
WHERE book.id = $1;

-- name: getBookWithAuthor2 :many
SELECT sqlc.embed(book), sqlc.embed(author)
FROM book
JOIN author ON author.id = book.author_id
WHERE book.id = $1;

-- name: UpsertAuthorName1 :one
UPDATE author
SET name = CASE WHEN $1::bool THEN $2::text ELSE name END
RETURNING *;

-- name: UpsertAuthorName2 :one
UPDATE author
SET name = CASE WHEN sqlc.arg(set_name)::bool THEN sqlc.arg(name)::text ELSE name END
RETURNING *;

-- name: UpdateAuthor2 :one
UPDATE author
SET email = coalesce(sqlc.narg('email'), email),
    bio = coalesce(sqlc.narg('bio'), bio)
WHERE id = sqlc.arg('id')
RETURNING *;
