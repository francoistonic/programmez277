map.on('load', async () => {
  // Ajouter la source de donnée à mettre sur la carte.
  await map.addSource('marketplaces-source', {
    type: 'geojson',
    data: 'https://media.jawg.io/add-your-data/marketplaces.geojson',
  });

  // Charge une image externe pour être utilisée en tant qu'icône sur la carte.
  const image = await map.loadImage('https://media.jawg.io/add-your-data/shop.png');
  await map.addImage('marketplaces-image', image.data);
  // Configure l'affichage de la source de donnée en lui affectant l'image
  map.addLayer({
    id: 'marketplaces-layer',
    type: 'symbol',
    source: 'marketplaces-source',
    layout: {
      'icon-image': 'marketplaces-image',
      'icon-anchor': 'bottom',
      // Autorise plusieurs icônes à se chevaucher
      'icon-allow-overlap': true,
      // Réduit la taille de l'icône selectionné
      'icon-size': 0.75,
    },
  });

  // EMPLACEMENT ÉTAPE 3
});
