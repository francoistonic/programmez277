let featureName;
let popup;

// On va écouter les événements de clic sur la donnée que nous avons ajouté.
map.on('click', 'marketplaces-layer', (e) => {
  // Récupère le premier élément sélectionné sur la carte
  const feature = e.features[0];
  if (!feature || feature.properties.name === featureName) return;
  featureName = feature.properties.name;
  // Créer la popup qu'on affichera
  popup = new maplibregl.Popup({
    maxWidth: '324px',
    offset: 40,
    anchor: 'bottom',
  })
    // Les coordonnées de référence de la popup sont identiques à ceux du point récupéré
    .setLngLat(feature.geometry.coordinates)
    // Raw HTML qui doit être injecté dans la popup.
    .setHTML(feature.properties.name)
    .addTo(map);

  popup.on('close', () => {
    // On met à zéro la propriété si la popup est toujours fermée
    if (!popup.isOpen()) {
      featureName = null;
    }
  });
});

// Amélioration de l'UX en changeant la souris en pointeur au-dessus des icônes.
map.on('mouseenter', 'marketplaces-layer', (e) => {
  map.getCanvas().style.cursor = 'pointer';
});
map.on('mouseleave', 'marketplaces-layer', () => {
  map.getCanvas().style.cursor = '';
});
