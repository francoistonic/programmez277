// Ajoute la barre de recherche pour le geocoding.
map.addControl(new JawgPlaces.MapLibre({ searchOnTyping: true, boundary: { countries: 'FRA' } }));
